#include "buzzer.h"
void buzz_control(uint16_t tim){

HAL_GPIO_WritePin(buzzer_GPIO_Port,buzzer_Pin,GPIO_PIN_SET);
HAL_Delay(tim);
HAL_GPIO_WritePin(buzzer_GPIO_Port,buzzer_Pin,GPIO_PIN_RESET);

}
