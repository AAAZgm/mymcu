#ifndef __MENU_H__
#define __MENU_H__

int menu1(void);
int menu2_motor(void);
int menu2_code(void);
int menu2_servo(void);
int menu2_read(void);

int menu2_listen(void);


int menu2_bluetooth(void);

int menu2_sleep(void);
#endif
