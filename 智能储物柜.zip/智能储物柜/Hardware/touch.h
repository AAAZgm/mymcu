#ifndef __touch_H_
#define __touch_H_
int touch_init(void);
uint8_t  Key_GetNum(void);

#endif
