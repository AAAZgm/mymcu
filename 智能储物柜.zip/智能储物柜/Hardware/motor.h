#ifndef __motor_H_
#define __motor_H_
void motor_Setv(float v);
void motor_init(void);
#endif
