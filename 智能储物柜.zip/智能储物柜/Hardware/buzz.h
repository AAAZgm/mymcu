#ifndef __buzz_H_
#define __buzz_H_
void buzz_Init(void);
void buzz1_ON(void);
void buzz1_Turn(void);
#endif
