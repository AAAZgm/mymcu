#ifndef __SERVO_H_
#define __SERVO_H_

void servo_init(void);
void servo_Setangle1(float r);
void servo_Setangle2(float r);
#endif
