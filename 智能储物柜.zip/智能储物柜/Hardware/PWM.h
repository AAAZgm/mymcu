#ifndef __PWM_H_
#define __PWM_H_
void pwm_init(void);
void PWM_SetCompare2(float Compare2);
void PWM_SetCompare3(float Compare3);
void PWM_SetCompare4(float Compare4);
#endif
